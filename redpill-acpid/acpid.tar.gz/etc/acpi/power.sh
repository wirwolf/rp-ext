#!/bin/sh

logger -p err "Shutdown from ACPI"
/usr/syno/sbin/synopoweroff

